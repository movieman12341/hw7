To run my files:

1. Open file location in terminal for my files
2. In terminal, run the following code:

make all

./test

5. Done!